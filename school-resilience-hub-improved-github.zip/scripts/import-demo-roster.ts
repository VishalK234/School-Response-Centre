import "dotenv/config";
import { eq } from "drizzle-orm";
import { getDb } from "../server/db";
import { emergencyStatusHistory, schoolClasses, students, teachers } from "../drizzle/schema";

const classes = [
  { name: "8A · Cedar", gradeLevel: "Grade 8", room: "Block A / 204", teacherName: "Neha Kulkarni", subject: "Science" },
  { name: "7B · Juniper", gradeLevel: "Grade 7", room: "Block B / 112", teacherName: "Rohan Desai", subject: "Mathematics" },
  { name: "6C · Ash", gradeLevel: "Grade 6", room: "Block C / 018", teacherName: "Meera Thomas", subject: "English" },
  { name: "5A · Willow", gradeLevel: "Grade 5", room: "Block A / 106", teacherName: "Aditi Sen", subject: "Social Studies" },
  { name: "4B · Maple", gradeLevel: "Grade 4", room: "Block B / 108", teacherName: "Ishaan Verma", subject: "Environmental Studies" },
];

const names = [
  "Maya Iyer", "Kabir Shah", "Ananya Rao", "Vihaan Kapoor", "Arjun Nair", "Sara Joseph", "Zoya Khan", "Reyansh Patel", "Diya Menon", "Advait Sinha", "Ira Bose", "Neil Fernandes", "Tara Malhotra", "Rishi Bhat", "Aanya Pillai", "Dev Khanna", "Myra Das", "Advik Roy", "Kiara Jain", "Aarush Gupta", "Nisha Thomas", "Yuvan Reddy", "Meher Ali", "Aarav Mehta", "Saanvi Rao", "Rohan Kapoor", "Anika Shah", "Vivaan Nair", "Ishita Joseph", "Kian Khan", "Aarav Sharma", "Meera Nair", "Rudra Singh", "Aditi Kapoor", "Pari Menon", "Dhruv Shah", "Riya Bhat", "Om Patel", "Anvi Rao", "Kavya Das",
];

const db = await getDb();
if (!db) throw new Error("DATABASE_URL is not available");

const classIds = new Map<string, number>();
for (const classDef of classes) {
  const existing = await db.select().from(schoolClasses).where(eq(schoolClasses.name, classDef.name)).limit(1);
  if (existing[0]) {
    classIds.set(classDef.name, existing[0].id);
    continue;
  }
  const teacherResult = await db.insert(teachers).values({ fullName: classDef.teacherName, subject: classDef.subject }).$returningId();
  const classResult = await db.insert(schoolClasses).values({ name: classDef.name, gradeLevel: classDef.gradeLevel, room: classDef.room, teacherId: teacherResult[0]?.id, capacity: 40 }).$returningId();
  classIds.set(classDef.name, classResult[0]?.id ?? 0);
}

const imported: number[] = [];
for (let index = 0; index < names.length; index++) {
  const [firstName, ...lastParts] = names[index].split(" ");
  const lastName = lastParts.join(" ");
  const classDef = classes[index % classes.length];
  const studentCode = `DEMO-${String(index + 1).padStart(3, "0")}`;
  const status = index < 23 ? "needs_assistance" : index < 30 ? "missing" : "safe";
  const location = status === "missing" ? ["Last seen: Main gate", "Last seen: East corridor", "Last seen: Bus bay", "Last seen: Library steps", "Last seen: South exit", "Last seen: Courtyard", "Last seen: Block C"][index - 23] : status === "safe" ? ["Home confirmation", "North shelter", "Family contact", "East shelter", "Community centre"][index % 5] : ["Library assembly point", "North shelter", "East shelter", "Civic relief centre", "West shelter"][index % 5];
  const existing = await db.select().from(students).where(eq(students.studentCode, studentCode)).limit(1);
  if (existing[0]) {
    imported.push(existing[0].id);
    continue;
  }
  const result = await db.insert(students).values({
    studentCode,
    firstName,
    lastName,
    gradeLevel: classDef.gradeLevel,
    classId: classIds.get(classDef.name),
    guardianName: `${lastName} family`,
    guardianPhone: `+91 98${String(10000000 + index).slice(-8)}`,
    emergencyStatus: status,
    lastStatusLocation: location,
    lastStatusNotes: status === "missing" ? "Needs immediate verification by class teacher." : status === "safe" ? "Demo safe check-in confirmed." : "Demo roster record requiring coordinated assistance.",
  }).$returningId();
  const studentId = result[0]?.id;
  if (studentId) {
    imported.push(studentId);
    await db.insert(emergencyStatusHistory).values({ studentId, status, location, notes: status === "missing" ? "Demo missing/unreachable report." : status === "safe" ? "Demo safe check-in." : "Demo needs-assistance report." });
  }
}

console.log(JSON.stringify({ roster: "DEMO", studentsImportedOrPresent: imported.length, needsAssistance: 23, missing: 7, classes: classes.length }));
