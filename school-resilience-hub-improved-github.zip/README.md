# Northstar School Resilience Hub

Northstar School Resilience Hub is a disaster-resilient school operations platform for tracking students, teachers, classes, attendance, emergency status, announcements, and live response readiness.

The application combines a React command-center dashboard with an Express and tRPC backend, a MySQL-compatible database managed through Drizzle ORM, and Manus OAuth authentication.

## Core capabilities

- Student and class roster management.
- Teacher assignment and class readiness reporting.
- Attendance recording for present, absent, late, and excused states.
- Emergency status tracking for Safe, Needs assistance, Missing/Unreachable, Hospitalized, and Evacuated.
- Last-seen location and timestamp tracking for every student status update.
- Emergency announcements with severity and audience targeting.
- Live dashboard refresh every 10 seconds.
- Class-wise emergency reports.
- Admin and teacher role-aware workspaces.
- CSV export of the emergency incident roster for administrators.
- Public REST endpoints for health, dashboard, live status, students, classes, reports, and announcements.

## Technology stack

| Layer | Technology |
| --- | --- |
| Frontend | React 19, TypeScript, Vite, Tailwind CSS, shadcn/ui components |
| Client data | tRPC React, TanStack Query, SuperJSON |
| Backend | Node.js, Express, tRPC |
| Database | MySQL-compatible database, Drizzle ORM, Drizzle Kit |
| Authentication | Manus OAuth with role-aware sessions |
| Validation | Zod, TypeScript, Vitest |
| Deployment | WebDev-compatible Node runtime |

## Project layout

```text
school-resilience-hub/
├── client/                     # React application and command-center UI
│   ├── src/pages/              # Page-level screens
│   ├── src/components/         # Shared layout and UI components
│   ├── src/lib/trpc.ts         # Typed client contract
│   ├── src/App.tsx             # Frontend routes and providers
│   └── src/index.css           # Design system and global styles
├── server/                     # Backend application code
│   ├── _core/                  # Express, OAuth, tRPC, storage, and runtime wiring
│   ├── db.ts                   # Database queries and resilient fallback data
│   ├── routers.ts              # tRPC procedures and role guards
│   └── *.test.ts               # Backend and contract tests
├── drizzle/                    # Database schema, migrations, and relations
├── scripts/                    # Repeatable data-import and seed scripts
├── shared/                     # Shared constants and types
├── docs/                       # API and architecture documentation
├── .github/workflows/          # Continuous integration checks
├── package.json                # Scripts and dependencies
└── README.md                   # This document
```

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for request flow and data relationships. See [docs/API.md](docs/API.md) for REST and tRPC contracts.

## Local development

### Prerequisites

Install Node.js 22 or a compatible current LTS release, pnpm 10, and a MySQL-compatible database. The project expects the database connection and authentication values to be supplied through environment variables.

### Installation

```bash
git clone <your-github-repository-url>
cd school-resilience-hub
pnpm install
```

Create a local `.env` file and fill it with the values required by the target environment. The required variable names are listed in the **Environment variables** section below. Do not commit `.env` files or production credentials.

### Environment variables

The runtime expects `DATABASE_URL`, `JWT_SECRET`, `VITE_APP_ID`, `OAUTH_SERVER_URL`, `VITE_OAUTH_PORTAL_URL`, `OWNER_OPEN_ID`, and `OWNER_NAME`. Optional framework integrations use `BUILT_IN_FORGE_API_URL`, `BUILT_IN_FORGE_API_KEY`, `VITE_FRONTEND_FORGE_API_URL`, and `VITE_FRONTEND_FORGE_API_KEY`. Analytics variables are optional.

### Database setup

`pnpm db:push` generates any pending migration from `drizzle/schema.ts` and applies it to the database in `DATABASE_URL`. Commit the generated files in `drizzle/` so every environment runs the same migrations.

```bash
pnpm db:push
```

To load the authorized demo roster:

```bash
pnpm import:demo-roster
```

The demo roster contains 40 students: 10 Safe, 23 Needs assistance, and 7 Missing/Unreachable.

### Run the application

```bash
pnpm dev
```

The development server serves the React dashboard and backend from the same process. The production commands are:

```bash
pnpm check
pnpm test
pnpm build
pnpm start
```

## Authentication and roles

Authentication uses Manus OAuth. The session user carries one of the supported roles: `admin`, `teacher`, `student`, or `user`. New accounts default to `student`; the account whose ID matches `OWNER_OPEN_ID` is made `admin` on first sign-in.

Write operations (create student, update emergency status, record attendance, publish announcement) require a signed-in `admin` or `teacher`. Administrators additionally see the roster export and announcement controls in the interface.

Read endpoints are public so the response dashboard keeps working during an incident. For callers who are not signed-in staff, guardian phone numbers are masked to their last four digits. Student names, classes, emergency status, and last-seen locations are still visible to the public; see **Known limitations** before loading real student data.

The `auth.access` tRPC procedure returns the current role and its permission set for client applications.

## REST API summary

The public API documentation is implemented at `/docs` in a running deployment. The main endpoints are:

```text
GET  /api/v1/health
GET  /api/v1/dashboard
GET  /api/v1/live-status
GET  /api/v1/students?status=needs_assistance
GET  /api/v1/classes
GET  /api/v1/classes/:id/report
GET  /api/v1/announcements
POST /api/v1/students                   authenticated staff
POST /api/v1/attendance                 authenticated staff
PATCH /api/v1/students/:id/status        authenticated staff
POST /api/v1/announcements               authenticated staff
```

For request examples and response fields, read [docs/API.md](docs/API.md).

## Testing

The test suite covers logout behavior, the staff access guards, input validation, phone-number redaction, class reports, and the built-in fallback data path. The fallback tests unset `DATABASE_URL` so they never touch a real database. The database code path is not covered by automated tests yet (see **Known limitations**).

Run all tests with:

```bash
pnpm test
```

Run static validation and the production build with:

```bash
pnpm check
pnpm build
```

Every pull request should pass the GitHub Actions workflow in `.github/workflows/ci.yml`.

## Safety and data handling

Emergency data is operationally sensitive. Use real student information only in an approved deployment with appropriate access controls. Keep secrets in environment variables, restrict database access, and avoid placing personal data in screenshots, test fixtures, commits, or public issue reports.

## Known limitations

These are deliberate gaps to close before using the system with real student data.

- **Student data is publicly readable.** Names, class, emergency status, and last-seen location are returned to unauthenticated callers. To restrict this, change the read procedures in `server/routers.ts` and the GET routes in `server/rest.ts` to require staff, and put a sign-in gate in front of the dashboard.
- **Teachers are not limited to their own classes.** Any teacher can update any student's status. The `teachers.userId` column exists to support this, but no code uses it yet.
- **Demonstration data is served when no roster is imported.** The dashboard shows a banner and `source: "fallback"` in this case. Writes made in that mode live in server memory only, are lost on restart, and are reported with `persisted: false`.
- **No rate limiting.** Add `express-rate-limit` (or a gateway) in front of the public endpoints.
- **Attendance has no database uniqueness rule.** The application updates an existing record for the same student and day, but two simultaneous requests could still create a duplicate. Add a unique index on `(studentId, attendanceDate)`.
- **The dashboard refreshes by polling every 10 seconds**, and each poll reads the full roster summary.

## License

This project is released under the MIT License. See [LICENSE](LICENSE).
