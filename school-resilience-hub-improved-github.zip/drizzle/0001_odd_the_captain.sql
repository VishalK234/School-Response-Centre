CREATE TABLE `attendance` (
	`id` int AUTO_INCREMENT NOT NULL,
	`studentId` int NOT NULL,
	`classId` int,
	`attendanceDate` date NOT NULL,
	`status` enum('present','absent','late','excused') NOT NULL,
	`notes` text,
	`recordedByUserId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `attendance_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `emergency_announcements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(180) NOT NULL,
	`message` text NOT NULL,
	`severity` enum('info','warning','critical') NOT NULL DEFAULT 'info',
	`audience` varchar(80) NOT NULL DEFAULT 'All families',
	`classId` int,
	`isActive` boolean NOT NULL DEFAULT true,
	`createdByUserId` int,
	`publishedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `emergency_announcements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `emergency_status_history` (
	`id` int AUTO_INCREMENT NOT NULL,
	`studentId` int NOT NULL,
	`status` enum('safe','needs_assistance','missing','hospitalized','evacuated') NOT NULL,
	`location` varchar(160),
	`notes` text,
	`reportedByUserId` int,
	`reportedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `emergency_status_history_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `school_classes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(80) NOT NULL,
	`gradeLevel` varchar(40) NOT NULL,
	`room` varchar(40),
	`teacherId` int,
	`capacity` int NOT NULL DEFAULT 40,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `school_classes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `students` (
	`id` int AUTO_INCREMENT NOT NULL,
	`studentCode` varchar(40) NOT NULL,
	`firstName` varchar(80) NOT NULL,
	`lastName` varchar(80) NOT NULL,
	`gradeLevel` varchar(40) NOT NULL,
	`classId` int,
	`guardianName` varchar(160),
	`guardianPhone` varchar(40),
	`emergencyStatus` enum('safe','needs_assistance','missing','hospitalized','evacuated') NOT NULL DEFAULT 'safe',
	`lastStatusLocation` varchar(160),
	`lastStatusNotes` text,
	`lastStatusUpdatedAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `students_id` PRIMARY KEY(`id`),
	CONSTRAINT `students_studentCode_unique` UNIQUE(`studentCode`)
);
--> statement-breakpoint
CREATE TABLE `teachers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`fullName` varchar(160) NOT NULL,
	`email` varchar(320),
	`phone` varchar(40),
	`subject` varchar(120),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `teachers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('user','admin','teacher','student') NOT NULL DEFAULT 'student';--> statement-breakpoint
ALTER TABLE `attendance` ADD CONSTRAINT `attendance_studentId_students_id_fk` FOREIGN KEY (`studentId`) REFERENCES `students`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `attendance` ADD CONSTRAINT `attendance_classId_school_classes_id_fk` FOREIGN KEY (`classId`) REFERENCES `school_classes`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `attendance` ADD CONSTRAINT `attendance_recordedByUserId_users_id_fk` FOREIGN KEY (`recordedByUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `emergency_announcements` ADD CONSTRAINT `emergency_announcements_classId_school_classes_id_fk` FOREIGN KEY (`classId`) REFERENCES `school_classes`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `emergency_announcements` ADD CONSTRAINT `emergency_announcements_createdByUserId_users_id_fk` FOREIGN KEY (`createdByUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `emergency_status_history` ADD CONSTRAINT `emergency_status_history_studentId_students_id_fk` FOREIGN KEY (`studentId`) REFERENCES `students`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `emergency_status_history` ADD CONSTRAINT `emergency_status_history_reportedByUserId_users_id_fk` FOREIGN KEY (`reportedByUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `school_classes` ADD CONSTRAINT `school_classes_teacherId_teachers_id_fk` FOREIGN KEY (`teacherId`) REFERENCES `teachers`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `students` ADD CONSTRAINT `students_classId_school_classes_id_fk` FOREIGN KEY (`classId`) REFERENCES `school_classes`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `teachers` ADD CONSTRAINT `teachers_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;