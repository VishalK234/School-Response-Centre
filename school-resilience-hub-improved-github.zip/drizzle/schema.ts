import {
  boolean,
  date,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";

/** Core user table backing Manus OAuth and role-aware access control. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin", "teacher", "student"]).default("student").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const teachers = mysqlTable("teachers", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").references(() => users.id),
  fullName: varchar("fullName", { length: 160 }).notNull(),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 40 }),
  subject: varchar("subject", { length: 120 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const schoolClasses = mysqlTable("school_classes", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 80 }).notNull(),
  gradeLevel: varchar("gradeLevel", { length: 40 }).notNull(),
  room: varchar("room", { length: 40 }),
  teacherId: int("teacherId").references(() => teachers.id),
  capacity: int("capacity").default(40).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const students = mysqlTable("students", {
  id: int("id").autoincrement().primaryKey(),
  studentCode: varchar("studentCode", { length: 40 }).notNull().unique(),
  firstName: varchar("firstName", { length: 80 }).notNull(),
  lastName: varchar("lastName", { length: 80 }).notNull(),
  gradeLevel: varchar("gradeLevel", { length: 40 }).notNull(),
  classId: int("classId").references(() => schoolClasses.id),
  guardianName: varchar("guardianName", { length: 160 }),
  guardianPhone: varchar("guardianPhone", { length: 40 }),
  emergencyStatus: mysqlEnum("emergencyStatus", [
    "safe",
    "needs_assistance",
    "missing",
    "hospitalized",
    "evacuated",
  ]).default("safe").notNull(),
  lastStatusLocation: varchar("lastStatusLocation", { length: 160 }),
  lastStatusNotes: text("lastStatusNotes"),
  lastStatusUpdatedAt: timestamp("lastStatusUpdatedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const attendance = mysqlTable("attendance", {
  id: int("id").autoincrement().primaryKey(),
  studentId: int("studentId").notNull().references(() => students.id),
  classId: int("classId").references(() => schoolClasses.id),
  attendanceDate: date("attendanceDate").notNull(),
  status: mysqlEnum("status", ["present", "absent", "late", "excused"]).notNull(),
  notes: text("notes"),
  recordedByUserId: int("recordedByUserId").references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const emergencyStatusHistory = mysqlTable("emergency_status_history", {
  id: int("id").autoincrement().primaryKey(),
  studentId: int("studentId").notNull().references(() => students.id),
  status: mysqlEnum("status", [
    "safe",
    "needs_assistance",
    "missing",
    "hospitalized",
    "evacuated",
  ]).notNull(),
  location: varchar("location", { length: 160 }),
  notes: text("notes"),
  reportedByUserId: int("reportedByUserId").references(() => users.id),
  reportedAt: timestamp("reportedAt").defaultNow().notNull(),
});

export const emergencyAnnouncements = mysqlTable("emergency_announcements", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 180 }).notNull(),
  message: text("message").notNull(),
  severity: mysqlEnum("severity", ["info", "warning", "critical"]).default("info").notNull(),
  audience: varchar("audience", { length: 80 }).default("All families").notNull(),
  classId: int("classId").references(() => schoolClasses.id),
  isActive: boolean("isActive").default(true).notNull(),
  createdByUserId: int("createdByUserId").references(() => users.id),
  publishedAt: timestamp("publishedAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Student = typeof students.$inferSelect;
export type Teacher = typeof teachers.$inferSelect;
export type SchoolClass = typeof schoolClasses.$inferSelect;
export type EmergencyStatus = typeof students.$inferSelect["emergencyStatus"];
export type AnnouncementSeverity = typeof emergencyAnnouncements.$inferSelect["severity"];
