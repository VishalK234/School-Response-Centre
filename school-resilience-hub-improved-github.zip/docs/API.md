# API Reference

Northstar exposes a public REST API for monitoring and a typed tRPC API for the web application. REST responses are JSON. Timestamps are Unix milliseconds unless a request explicitly uses an ISO date string.

## Base URL

For local development, use `http://localhost:3000`. For a deployed environment, replace the base URL with that environment's public URL.

## Public REST endpoints

| Method | Path | Purpose |
| --- | --- | --- |
| GET | `/api/v1/health` | Returns service health and server timestamp. |
| GET | `/api/v1/dashboard` | Returns totals, status distribution, classes, students, and active announcements. |
| GET | `/api/v1/live-status` | Returns whether data is live (`dataSource`: `database` or `fallback`), real database connectivity (`connected`, `unavailable`, or `not_configured`), and the latest update time. |
| GET | `/api/v1/students` | Returns student records. Supports `status` and `search` query parameters. |
| GET | `/api/v1/classes` | Returns classes, assigned teachers, roster counts, and attention counts. |
| GET | `/api/v1/classes/:id/report` | Returns a class roster and emergency status breakdown. Responds `404` if the class does not exist. |
| GET | `/api/v1/announcements` | Returns active emergency announcements. |

Guardian phone numbers in these responses are masked to their last four digits unless the caller is signed-in staff. Snapshot responses include `source` (`database` or `fallback`) and `studentsTruncated`; when `source` is `fallback` the figures are demonstration data.

Example:

```bash
curl http://localhost:3000/api/v1/dashboard
curl 'http://localhost:3000/api/v1/students?status=missing'
curl http://localhost:3000/api/v1/classes/1/report
```

## Authenticated REST writes

Write endpoints require a valid staff session. A staff session belongs to an `admin` or `teacher` user.

```text
POST  /api/v1/students
POST  /api/v1/attendance
PATCH /api/v1/students/:id/status
POST  /api/v1/announcements
```

Recording attendance twice for the same student and date updates the existing record. The browser dashboard normally uses the typed tRPC procedures for these actions. The REST routes exist for monitoring integrations and external operational clients.

## tRPC procedures

The web client calls the following procedures through `/api/trpc`:

```text
auth.me
auth.access
auth.logout

dashboard.snapshot
students.list
students.create
students.updateStatus
classes.list
classes.report
attendance.record
announcements.list
announcements.create
```

`students.create`, `students.updateStatus`, `attendance.record`, and `announcements.create` are protected by the staff role guard. The `auth.access` procedure returns the current role and permissions.

## Emergency status values

```text
safe
needs_assistance
missing
hospitalized
evacuated
```

Every status update stores the status, optional location, optional notes, reporting user, and timestamp. The dashboard presents the latest value and the last-seen location for each student.

## Error behavior

Request bodies are validated with the schemas in `shared/schemas.ts`, which both REST and tRPC use. Invalid input returns `400` (`BAD_REQUEST`). Attendance dates must be `YYYY-MM-DD`.

| Situation | REST | tRPC |
| --- | --- | --- |
| Not signed in | 401 | `UNAUTHORIZED` |
| Signed in but not admin/teacher | 403 | `FORBIDDEN` |
| Student or class does not exist (real roster present) | 404 | `NOT_FOUND` |
| Duplicate student code | 409 | `CONFLICT` |
| Database required but unavailable (student creation) | 503 | `SERVICE_UNAVAILABLE` |

Unexpected server errors return a generic `500`; database messages are logged, never returned to the client.

If the database is unreachable or no roster has been imported, reads serve the fallback snapshot and status, attendance, and announcement writes are kept in server memory only. Those responses carry `persisted: false`. When a real roster exists, an unknown student id is rejected instead of being accepted silently.
