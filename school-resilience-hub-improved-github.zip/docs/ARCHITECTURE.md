# System Architecture

Northstar is a single-process full-stack application. The Express server hosts the REST API, tRPC adapter, OAuth callback, and Vite development bridge. The React client uses the typed tRPC contract instead of maintaining a second handwritten API client.

## Request flow

```text
Browser
  │
  ├── React dashboard
  │     └── tRPC React client
  │
  └── Express server
        ├── Manus OAuth callback and session cookie
        ├── /api/v1 REST monitoring routes
        ├── /api/trpc typed application routes
        └── Drizzle ORM
              └── MySQL-compatible database
```

The dashboard refreshes its snapshot every 10 seconds. Each refresh updates summary counts, status distribution, class readiness, active announcements, and the last-updated clock.

## Backend responsibilities

`server/_core/index.ts` configures Express and registers REST routes. `server/_core/context.ts` creates the request context and exposes the authenticated session user to tRPC. `server/_core/trpc.ts` defines public, protected, and admin procedure primitives.

`server/routers.ts` is the application contract. It validates inputs with the shared Zod schemas in `shared/schemas.ts` and applies the staff role guard to all state-changing operations. `server/rest.ts` exposes the same operations over REST using the same schemas. `server/privacy.ts` masks guardian phone numbers for non-staff viewers, and `server/errors.ts` defines the typed errors that both transports translate into 404, 409, and 503 responses. `server/db.ts` contains reusable query helpers, dashboard aggregation, fallback data, and persistence functions.

## Data model

| Table | Responsibility |
| --- | --- |
| `users` | OAuth identities, session metadata, and roles. |
| `teachers` | Teacher profiles and account linkage. |
| `school_classes` | Class names, grade levels, rooms, capacity, and teacher assignment. |
| `students` | Student roster, guardian contact, current emergency status, and last-seen data. |
| `attendance` | Daily attendance records and reporting user. |
| `emergency_status_history` | Append-only history of emergency status changes. |
| `emergency_announcements` | Active and historical emergency broadcasts. |

All business timestamps are stored as UTC-backed database timestamps and converted for display in the browser.

## Authentication and authorization

Manus OAuth creates the session cookie. The authenticated user record includes a role. The supported role values are `admin`, `teacher`, `student`, and `user`.

The staff guard permits `admin` and `teacher` users to perform operational writes. Administrator controls add report export, announcement publishing, roster management, and broad class visibility. Teacher controls focus on assigned classes, attendance, and emergency status updates.

## Resilience behavior

The dashboard uses database-backed data when a connection is available. If the database is unavailable or contains no imported roster, `server/db.ts` returns a deterministic fallback snapshot marked `source: "fallback"`, and the dashboard shows a banner so operators cannot mistake it for live data. Writes made in that mode are held in server memory, reported with `persisted: false`, and lost on restart.

When the database is connected and a roster exists, totals come from SQL aggregates rather than the 500-row student list, and status updates write the student row and its history row in one transaction.

## Testing strategy

Vitest tests exercise auth behavior, dashboard aggregation, class reporting, attendance, emergency status updates, announcements, and fallback behavior. TypeScript checking catches contract drift between client and server. The production build validates both the Vite client bundle and the bundled Node server.
