import type { Express, Request, Response } from "express";
import type { ZodType } from "zod";
import { sdk } from "./_core/sdk";
import {
  createAnnouncement,
  createStudentRecord,
  getClassReport,
  getDashboardSnapshot,
  listAnnouncements,
  listClasses,
  listDashboardStudents,
  pingDatabase,
  recordAttendance,
  updateStudentEmergencyStatus,
} from "./db";
import { AppError, HTTP_STATUS } from "./errors";
import { isStaff, redactSnapshot, redactStudents } from "./privacy";
import {
  createAnnouncementSchema,
  createStudentSchema,
  idSchema,
  recordAttendanceSchema,
  studentListQuerySchema,
  updateStatusBodySchema,
} from "@shared/schemas";

async function getRequestUser(req: Request) {
  try {
    return await sdk.authenticateRequest(req);
  } catch {
    return null;
  }
}

/** Resolves the staff user, or answers 401/403 itself and returns null. */
async function requireStaff(req: Request, res: Response) {
  const user = await getRequestUser(req);
  if (!user) {
    res.status(401).json({ error: "Authentication required" });
    return null;
  }
  if (!isStaff(user)) {
    res.status(403).json({ error: "Staff access required" });
    return null;
  }
  return user;
}

function sendError(res: Response, error: unknown) {
  if (error instanceof AppError) return res.status(HTTP_STATUS[error.kind]).json({ error: error.message });
  // Never echo raw database/driver messages to API clients.
  console.error("[REST] Unhandled error:", error);
  return res.status(500).json({ error: "Internal server error" });
}

/** Express 4 does not catch rejected promises, so every async route goes through here. */
function handle(work: (req: Request, res: Response) => Promise<unknown>) {
  return async (req: Request, res: Response) => {
    try {
      await work(req, res);
    } catch (error) {
      if (!res.headersSent) sendError(res, error);
    }
  };
}

function parse<T>(schema: ZodType<T>, value: unknown, res: Response): T | null {
  const result = schema.safeParse(value);
  if (!result.success) {
    res.status(400).json({ error: result.error.issues.map(issue => ({ path: issue.path, message: issue.message })) });
    return null;
  }
  return result.data;
}

const DOCS_HTML = `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Northstar API Documentation</title><style>body{font-family:system-ui,-apple-system,sans-serif;max-width:920px;margin:40px auto;padding:0 20px;color:#183830}h1{font-size:32px}h2{margin-top:30px}code{background:#edf3ed;padding:3px 6px;border-radius:5px}li{margin:10px 0}a{color:#247a5d}</style></head><body><h1>Northstar School Resilience API</h1><p>REST API for students, classes, attendance, emergency status, live monitoring, and announcements.</p><h2>Public endpoints</h2><p>Guardian phone numbers are masked for callers who are not signed in as staff.</p><ul><li><code>GET /api/v1/health</code> — service health</li><li><code>GET /api/v1/dashboard</code> — dashboard snapshot and emergency totals</li><li><code>GET /api/v1/live-status</code> — live operational status and database connectivity</li><li><code>GET /api/v1/students?status=needs_assistance</code> — filtered student records</li><li><code>GET /api/v1/classes</code> — class roster coverage</li><li><code>GET /api/v1/classes/:id/report</code> — class-wise emergency report (404 if the class does not exist)</li><li><code>GET /api/v1/announcements</code> — recent announcements</li></ul><h2>Staff-only write endpoints</h2><ul><li><code>POST /api/v1/students</code> — create a student</li><li><code>POST /api/v1/attendance</code> — record attendance (re-marking the same day updates the record)</li><li><code>PATCH /api/v1/students/:id/status</code> — update emergency status</li><li><code>POST /api/v1/announcements</code> — publish an emergency announcement</li></ul><p>Interactive dashboard: <a href="/">Open Northstar Response Center</a></p></body></html>`;

export function registerRestRoutes(app: Express) {
  app.get("/docs", (_req, res) => {
    res.type("html").send(DOCS_HTML);
  });

  app.get("/api/v1/health", (_req, res) => {
    res.json({ status: "ok", service: "school-resilience-hub", timestamp: Date.now() });
  });

  app.get("/api/v1/dashboard", handle(async (req, res) => {
    const staff = isStaff(await getRequestUser(req));
    res.json(redactSnapshot(await getDashboardSnapshot(), staff));
  }));

  app.get("/api/v1/live-status", handle(async (_req, res) => {
    const [snapshot, database] = await Promise.all([getDashboardSnapshot(), pingDatabase()]);
    res.json({
      live: snapshot.source === "database",
      dataSource: snapshot.source,
      checkedAt: Date.now(),
      lastUpdatedAt: snapshot.lastUpdatedAt,
      services: { api: "operational", database },
      summary: snapshot.summary,
    });
  }));

  app.get("/api/v1/students", handle(async (req, res) => {
    const query = parse(studentListQuerySchema, req.query, res);
    if (!query) return;
    const staff = isStaff(await getRequestUser(req));
    res.json(redactStudents(await listDashboardStudents(query), staff));
  }));

  app.get("/api/v1/classes", handle(async (_req, res) => {
    res.json(await listClasses());
  }));

  app.get("/api/v1/classes/:id/report", handle(async (req, res) => {
    const id = idSchema.safeParse(Number(req.params.id));
    if (!id.success) return res.status(400).json({ error: "Invalid class id" });
    const report = await getClassReport(id.data);
    if (!report.class) return res.status(404).json({ error: "Class not found" });
    const staff = isStaff(await getRequestUser(req));
    return res.json({ ...report, students: redactStudents(report.students, staff) });
  }));

  app.get("/api/v1/announcements", handle(async (_req, res) => {
    res.json(await listAnnouncements());
  }));

  app.post("/api/v1/students", handle(async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    const body = parse(createStudentSchema, req.body, res);
    if (!body) return;
    res.status(201).json({ id: await createStudentRecord(body) });
  }));

  app.patch("/api/v1/students/:id/status", handle(async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    const studentId = idSchema.safeParse(Number(req.params.id));
    if (!studentId.success) return res.status(400).json({ error: "Invalid student id" });
    const body = parse(updateStatusBodySchema, req.body, res);
    if (!body) return;
    return res.json(await updateStudentEmergencyStatus({ studentId: studentId.data, ...body, reportedByUserId: user.id }));
  }));

  app.post("/api/v1/attendance", handle(async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    const body = parse(recordAttendanceSchema, req.body, res);
    if (!body) return;
    res.status(201).json(await recordAttendance({ ...body, recordedByUserId: user.id }));
  }));

  app.post("/api/v1/announcements", handle(async (req, res) => {
    const user = await requireStaff(req, res);
    if (!user) return;
    const body = parse(createAnnouncementSchema, req.body, res);
    if (!body) return;
    res.status(201).json(await createAnnouncement({ ...body, createdByUserId: user.id }));
  }));
}
