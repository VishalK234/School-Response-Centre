/**
 * Domain errors thrown by the data layer. The transport layers (tRPC and REST)
 * translate these into the right status code, so database internals are never
 * echoed back to API clients.
 */
export type AppErrorKind = "not_found" | "conflict" | "unavailable";

export class AppError extends Error {
  constructor(
    readonly kind: AppErrorKind,
    message: string
  ) {
    super(message);
    this.name = "AppError";
  }
}

export const notFound = (message: string) => new AppError("not_found", message);
export const conflict = (message: string) => new AppError("conflict", message);
export const unavailable = (message: string) => new AppError("unavailable", message);

export const HTTP_STATUS: Record<AppErrorKind, number> = {
  not_found: 404,
  conflict: 409,
  unavailable: 503,
};
