import type { DashboardSnapshot, DashboardStudent } from "./db";

type MaybeRole = { role: string } | null | undefined;

/** Staff are admins and teachers. Everyone else (including anonymous visitors) is a public viewer. */
export function isStaff(user: MaybeRole): boolean {
  return !!user && (user.role === "admin" || user.role === "teacher");
}

/** Keeps only the last four digits so a public viewer can never read a guardian's full number. */
export function maskPhone(phone: string): string {
  const digits = phone.replace(/\D/g, "");
  if (digits.length < 5) return phone === "Not provided" ? phone : "•••••";
  return `••••• ${digits.slice(-4)}`;
}

export function redactStudent<T extends Pick<DashboardStudent, "guardianPhone">>(student: T, viewerIsStaff: boolean): T {
  return viewerIsStaff ? student : { ...student, guardianPhone: maskPhone(student.guardianPhone) };
}

export function redactStudents<T extends Pick<DashboardStudent, "guardianPhone">>(list: T[], viewerIsStaff: boolean): T[] {
  return viewerIsStaff ? list : list.map(student => redactStudent(student, false));
}

export function redactSnapshot(snapshot: DashboardSnapshot, viewerIsStaff: boolean): DashboardSnapshot {
  return viewerIsStaff ? snapshot : { ...snapshot, students: redactStudents(snapshot.students, false) };
}
