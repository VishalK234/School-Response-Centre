import { and, desc, eq, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  attendance,
  emergencyAnnouncements,
  emergencyStatusHistory,
  schoolClasses,
  students,
  teachers,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";
import { AppError, conflict, notFound, unavailable } from "./errors";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

type Db = NonNullable<Awaited<ReturnType<typeof getDb>>>;

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  values.lastSignedIn ??= new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export type DashboardStudent = {
  id: number;
  classId: number | null;
  studentCode: string;
  name: string;
  gradeLevel: string;
  className: string;
  teacherName: string;
  status: string;
  location: string;
  guardianPhone: string;
  lastUpdated: number;
};

export type DashboardSnapshot = {
  /** "database" = real roster. "fallback" = built-in demonstration data. UIs must make this visible. */
  source: "database" | "fallback";
  /** True when more students exist than the `students` list contains. Summary counts are always complete. */
  studentsTruncated: boolean;
  summary: {
    totalStudents: number;
    safe: number;
    needsAssistance: number;
    missing: number;
    hospitalized: number;
    evacuated: number;
    classesReporting: number;
    totalClasses: number;
  };
  statusBreakdown: Array<{ label: string; value: number; color: string }>;
  classes: Array<{
    id: number;
    name: string;
    gradeLevel: string;
    room: string;
    teacherName: string;
    studentCount: number;
    needsAttention: number;
  }>;
  students: DashboardStudent[];
  announcements: Array<{
    id: number;
    title: string;
    message: string;
    severity: string;
    audience: string;
    publishedAt: number;
  }>;
  lastUpdatedAt: number;
};

const statusLabels: Record<string, string> = {
  safe: "Safe",
  needs_assistance: "Needs assistance",
  missing: "Missing / unreachable",
  hospitalized: "Hospitalized",
  evacuated: "Evacuated",
};

const statusColors: Record<string, string> = {
  safe: "#2F9B79",
  needs_assistance: "#E7A33E",
  missing: "#D86655",
  hospitalized: "#8A74C7",
  evacuated: "#5D8DC9",
};

const fallbackStudentRows: Array<Omit<DashboardStudent, "classId">> = [
  { id: 101, studentCode: "SRH-1042", name: "Aarav Mehta", gradeLevel: "Grade 8", className: "8A · Cedar", teacherName: "Neha Kulkarni", status: "safe", location: "North shelter", guardianPhone: "+91 98••• 1042", lastUpdated: Date.now() - 8 * 60_000 },
  { id: 102, studentCode: "SRH-1118", name: "Maya Iyer", gradeLevel: "Grade 8", className: "8A · Cedar", teacherName: "Neha Kulkarni", status: "needs_assistance", location: "Library assembly point", guardianPhone: "+91 98••• 1118", lastUpdated: Date.now() - 12 * 60_000 },
  { id: 103, studentCode: "SRH-2034", name: "Kabir Shah", gradeLevel: "Grade 7", className: "7B · Juniper", teacherName: "Rohan Desai", status: "safe", location: "East shelter", guardianPhone: "+91 98••• 2034", lastUpdated: Date.now() - 15 * 60_000 },
  { id: 104, studentCode: "SRH-2067", name: "Ananya Rao", gradeLevel: "Grade 7", className: "7B · Juniper", teacherName: "Rohan Desai", status: "missing", location: "Last seen: Main gate", guardianPhone: "+91 98••• 2067", lastUpdated: Date.now() - 18 * 60_000 },
  { id: 105, studentCode: "SRH-3091", name: "Vihaan Kapoor", gradeLevel: "Grade 6", className: "6C · Ash", teacherName: "Meera Thomas", status: "evacuated", location: "Civic relief centre", guardianPhone: "+91 98••• 3091", lastUpdated: Date.now() - 22 * 60_000 },
  { id: 106, studentCode: "SRH-3155", name: "Sara Joseph", gradeLevel: "Grade 6", className: "6C · Ash", teacherName: "Meera Thomas", status: "safe", location: "West shelter", guardianPhone: "+91 98••• 3155", lastUpdated: Date.now() - 28 * 60_000 },
  { id: 107, studentCode: "SRH-4012", name: "Arjun Nair", gradeLevel: "Grade 5", className: "5A · Willow", teacherName: "Aditi Sen", status: "hospitalized", location: "CityCare Hospital", guardianPhone: "+91 98••• 4012", lastUpdated: Date.now() - 35 * 60_000 },
  { id: 108, studentCode: "SRH-4050", name: "Zoya Khan", gradeLevel: "Grade 5", className: "5A · Willow", teacherName: "Aditi Sen", status: "safe", location: "South shelter", guardianPhone: "+91 98••• 4050", lastUpdated: Date.now() - 41 * 60_000 },
];

const fallbackClasses = [
  { id: 1, name: "8A · Cedar", gradeLevel: "Grade 8", room: "Block A / 204", teacherName: "Neha Kulkarni", studentCount: 32, needsAttention: 4 },
  { id: 2, name: "7B · Juniper", gradeLevel: "Grade 7", room: "Block B / 112", teacherName: "Rohan Desai", studentCount: 30, needsAttention: 3 },
  { id: 3, name: "6C · Ash", gradeLevel: "Grade 6", room: "Block C / 018", teacherName: "Meera Thomas", studentCount: 29, needsAttention: 2 },
  { id: 4, name: "5A · Willow", gradeLevel: "Grade 5", room: "Block A / 106", teacherName: "Aditi Sen", studentCount: 31, needsAttention: 2 },
  { id: 5, name: "4B · Maple", gradeLevel: "Grade 4", room: "Block B / 108", teacherName: "Ishaan Verma", studentCount: 28, needsAttention: 1 },
];

const fallbackAnnouncements = [
  { id: 1, title: "Assembly point update", message: "All Grade 5–8 groups should remain at their assigned shelter until the all-clear is issued.", severity: "warning", audience: "All families", publishedAt: Date.now() - 24 * 60_000 },
  { id: 2, title: "Road closure near east gate", message: "The east gate is closed. Family pickup is being coordinated through the civic relief centre.", severity: "critical", audience: "Grade 6–8 families", publishedAt: Date.now() - 48 * 60_000 },
  { id: 3, title: "Roll call window extended", message: "Teachers have an additional 15 minutes to confirm late arrivals against the shelter roster.", severity: "info", audience: "All teachers", publishedAt: Date.now() - 76 * 60_000 },
];

const runtimeStudentOverrides = new Map<number, { status: DashboardStudent["status"]; location: string; lastUpdated: number }>();
const runtimeAnnouncements: DashboardSnapshot["announcements"] = [];
const runtimeAttendanceOverrides = new Map<number, "present" | "absent" | "late">();

const fallbackClassIdByName = new Map(fallbackClasses.map(item => [item.name, item.id]));

function fallbackSnapshot(): DashboardSnapshot {
  const students: DashboardStudent[] = fallbackStudentRows.map(row => {
    const student: DashboardStudent = { ...row, classId: fallbackClassIdByName.get(row.className) ?? null };
    const override = runtimeStudentOverrides.get(student.id);
    return override ? { ...student, status: override.status, location: override.location, lastUpdated: override.lastUpdated } : student;
  });
  const counts: Record<string, number> = { safe: 268, needs_assistance: 23, missing: 7, hospitalized: 6, evacuated: 8 };
  runtimeStudentOverrides.forEach((override, studentId) => {
    const original = fallbackStudentRows.find(student => student.id === studentId);
    if (original && original.status !== override.status) {
      counts[original.status] -= 1;
      counts[override.status] += 1;
    }
  });
  return {
    source: "fallback",
    studentsTruncated: false,
    summary: { totalStudents: 312, safe: counts.safe, needsAssistance: counts.needs_assistance, missing: counts.missing, hospitalized: counts.hospitalized, evacuated: counts.evacuated, classesReporting: 18, totalClasses: 20 },
    // Derived from the same counts as `summary` so the two can never disagree (they previously did after a status update).
    statusBreakdown: Object.entries(statusLabels).map(([key, label]) => ({ label, value: counts[key] ?? 0, color: statusColors[key] })),
    classes: fallbackClasses,
    students,
    announcements: [...runtimeAnnouncements, ...fallbackAnnouncements],
    lastUpdatedAt: Date.now(),
  };
}

function toDashboardStudent(student: typeof students.$inferSelect, className: string, teacherName: string): DashboardStudent {
  return {
    id: student.id,
    classId: student.classId,
    studentCode: student.studentCode,
    name: `${student.firstName} ${student.lastName}`,
    gradeLevel: student.gradeLevel,
    className,
    teacherName,
    status: student.emergencyStatus,
    location: student.lastStatusLocation ?? "Not reported",
    guardianPhone: student.guardianPhone ?? "Not provided",
    lastUpdated: student.lastStatusUpdatedAt.getTime(),
  };
}

/** True when the connected database holds any roster data (students or classes). */
async function hasRoster(db: Db): Promise<boolean> {
  const [studentRow] = await db.select({ id: students.id }).from(students).limit(1);
  if (studentRow) return true;
  const [classRow] = await db.select({ id: schoolClasses.id }).from(schoolClasses).limit(1);
  return !!classRow;
}

/** Real connectivity check, used by the live-status endpoint instead of a hard-coded string. */
export async function pingDatabase(): Promise<"connected" | "unavailable" | "not_configured"> {
  if (!process.env.DATABASE_URL) return "not_configured";
  const db = await getDb();
  if (!db) return "unavailable";
  try {
    await db.execute(sql`select 1`);
    return "connected";
  } catch {
    return "unavailable";
  }
}

const STUDENT_LIST_LIMIT = 500;

export async function getDashboardSnapshot(): Promise<DashboardSnapshot> {
  const db = await getDb();
  if (!db) return fallbackSnapshot();
  try {
    const [studentRows, classRows, teacherRows, announcementRows, statusRows, classStatusRows] = await Promise.all([
      db.select().from(students).orderBy(desc(students.lastStatusUpdatedAt)).limit(STUDENT_LIST_LIMIT),
      db.select().from(schoolClasses),
      db.select().from(teachers),
      db.select().from(emergencyAnnouncements).where(eq(emergencyAnnouncements.isActive, true)).orderBy(desc(emergencyAnnouncements.publishedAt)).limit(20),
      // Counts come from the database, not from the (limited) student list, so totals stay correct for large schools.
      db.select({ status: students.emergencyStatus, total: sql<number>`count(*)` }).from(students).groupBy(students.emergencyStatus),
      db.select({ classId: students.classId, status: students.emergencyStatus, total: sql<number>`count(*)` }).from(students).groupBy(students.classId, students.emergencyStatus),
    ]);

    const statusCounts = new Map<string, number>();
    for (const row of statusRows) statusCounts.set(row.status, Number(row.total));
    const totalStudents = Array.from(statusCounts.values()).reduce((sum, value) => sum + value, 0);
    if (totalStudents === 0 && classRows.length === 0) return fallbackSnapshot();

    const classMap = new Map(classRows.map(item => [item.id, item]));
    const teacherMap = new Map(teacherRows.map(item => [item.id, item]));
    const classTotals = new Map<number, { count: number; attention: number }>();
    for (const row of classStatusRows) {
      if (row.classId === null) continue;
      const entry = classTotals.get(row.classId) ?? { count: 0, attention: 0 };
      entry.count += Number(row.total);
      if (row.status !== "safe") entry.attention += Number(row.total);
      classTotals.set(row.classId, entry);
    }

    const statusBreakdown = Object.entries(statusLabels).map(([key, label]) => ({ label, value: statusCounts.get(key) ?? 0, color: statusColors[key] }));
    const dashboardStudents = studentRows.map(student => {
      const classRecord = classMap.get(student.classId ?? 0);
      return toDashboardStudent(student, classRecord?.name ?? "Unassigned", classRecord?.teacherId ? (teacherMap.get(classRecord.teacherId)?.fullName ?? "Unassigned") : "Unassigned");
    });
    const dashboardClasses = classRows.map(item => {
      const totals = classTotals.get(item.id) ?? { count: 0, attention: 0 };
      return {
        id: item.id,
        name: item.name,
        gradeLevel: item.gradeLevel,
        room: item.room ?? "Room not set",
        teacherName: item.teacherId ? (teacherMap.get(item.teacherId)?.fullName ?? "Unassigned") : "Unassigned",
        studentCount: totals.count,
        needsAttention: totals.attention,
      };
    });
    return {
      source: "database",
      studentsTruncated: totalStudents > studentRows.length,
      summary: {
        totalStudents,
        safe: statusCounts.get("safe") ?? 0,
        needsAssistance: statusCounts.get("needs_assistance") ?? 0,
        missing: statusCounts.get("missing") ?? 0,
        hospitalized: statusCounts.get("hospitalized") ?? 0,
        evacuated: statusCounts.get("evacuated") ?? 0,
        classesReporting: dashboardClasses.filter(item => item.studentCount > 0).length,
        totalClasses: dashboardClasses.length,
      },
      statusBreakdown,
      classes: dashboardClasses,
      students: dashboardStudents,
      announcements: announcementRows.map(item => ({ id: item.id, title: item.title, message: item.message, severity: item.severity, audience: item.audience, publishedAt: item.publishedAt.getTime() })),
      lastUpdatedAt: Date.now(),
    };
  } catch (error) {
    console.warn("[Database] Dashboard query failed; using resilient fallback:", error);
    return fallbackSnapshot();
  }
}

export async function listDashboardStudents(input?: { status?: string; search?: string }) {
  const snapshot = await getDashboardSnapshot();
  const normalized = input?.search?.trim().toLowerCase();
  return snapshot.students.filter(student => {
    const matchesStatus = !input?.status || student.status === input.status;
    const haystack = `${student.name} ${student.studentCode} ${student.className}`.toLowerCase();
    return matchesStatus && (!normalized || haystack.includes(normalized));
  });
}

export async function listAnnouncements() {
  return (await getDashboardSnapshot()).announcements;
}

export async function listClasses() {
  return (await getDashboardSnapshot()).classes;
}

type ClassSummary = DashboardSnapshot["classes"][number];

function buildClassReport(classItem: ClassSummary | null, classStudents: DashboardStudent[]) {
  return {
    class: classItem,
    students: classStudents,
    statusBreakdown: Object.entries(statusLabels).map(([key, label]) => ({ label, value: classStudents.filter(student => student.status === key).length, color: statusColors[key] })),
    generatedAt: Date.now(),
  };
}

/**
 * Class-wise emergency report. Students are matched by classId (the old code matched on the class *name*,
 * so two classes with the same name were merged) and read straight from the database so the report is not
 * cut off by the dashboard's 500-student list limit. `class` is null when the class does not exist.
 */
export async function getClassReport(classId: number) {
  const db = await getDb();
  if (db) {
    try {
      const [classRows, studentRows] = await Promise.all([
        db.select({ item: schoolClasses, teacherName: teachers.fullName }).from(schoolClasses).leftJoin(teachers, eq(schoolClasses.teacherId, teachers.id)).where(eq(schoolClasses.id, classId)).limit(1),
        db.select().from(students).where(eq(students.classId, classId)).orderBy(desc(students.lastStatusUpdatedAt)),
      ]);
      const row = classRows[0];
      if (row) {
        const teacherName = row.teacherName ?? "Unassigned";
        const list = studentRows.map(student => toDashboardStudent(student, row.item.name, teacherName));
        return buildClassReport(
          { id: row.item.id, name: row.item.name, gradeLevel: row.item.gradeLevel, room: row.item.room ?? "Room not set", teacherName, studentCount: list.length, needsAttention: list.filter(student => student.status !== "safe").length },
          list,
        );
      }
      if (await hasRoster(db)) return buildClassReport(null, []);
    } catch (error) {
      console.warn("[Database] Class report query failed; using resilient fallback:", error);
    }
  }
  const snapshot = fallbackSnapshot();
  const classItem = snapshot.classes.find(item => item.id === classId) ?? null;
  return buildClassReport(classItem, classItem ? snapshot.students.filter(student => student.classId === classId) : []);
}

function mysqlErrorCode(error: unknown): string | undefined {
  const candidate = error as { code?: string; cause?: { code?: string } } | null;
  return candidate?.code ?? candidate?.cause?.code;
}

export async function createStudentRecord(input: {
  studentCode: string;
  firstName: string;
  lastName: string;
  gradeLevel: string;
  classId?: number;
  guardianName?: string;
  guardianPhone?: string;
}) {
  const db = await getDb();
  if (!db) throw unavailable("The student database is not available.");
  try {
    const result = await db.insert(students).values(input).$returningId();
    return result[0]?.id;
  } catch (error) {
    const code = mysqlErrorCode(error);
    if (code === "ER_DUP_ENTRY") throw conflict(`Student code ${input.studentCode} already exists.`);
    if (code === "ER_NO_REFERENCED_ROW_2") throw notFound(`Class ${input.classId} was not found.`);
    throw error;
  }
}

export async function updateStudentEmergencyStatus(input: {
  studentId: number;
  status: "safe" | "needs_assistance" | "missing" | "hospitalized" | "evacuated";
  location?: string;
  notes?: string;
  reportedByUserId?: number;
}) {
  const db = await getDb();
  if (db) {
    try {
      const [existing] = await db.select({ id: students.id }).from(students).where(eq(students.id, input.studentId)).limit(1);
      if (existing) {
        const now = new Date();
        // One transaction so the student row and its audit-history row can never disagree.
        await db.transaction(async tx => {
          await tx.update(students).set({ emergencyStatus: input.status, lastStatusLocation: input.location, lastStatusNotes: input.notes, lastStatusUpdatedAt: now }).where(eq(students.id, input.studentId));
          await tx.insert(emergencyStatusHistory).values({ studentId: input.studentId, status: input.status, location: input.location, notes: input.notes, reportedByUserId: input.reportedByUserId, reportedAt: now });
        });
        return { success: true, updatedAt: now.getTime(), persisted: true };
      }
      // A real roster exists, so an unknown id is a mistake and must not be reported as success.
      if (await hasRoster(db)) throw notFound(`Student ${input.studentId} was not found.`);
    } catch (error) {
      if (error instanceof AppError) throw error;
      console.warn("[Database] Status update failed; keeping it in memory only:", error);
    }
  }
  runtimeStudentOverrides.set(input.studentId, { status: input.status, location: input.location ?? "Not reported", lastUpdated: Date.now() });
  return { success: true, updatedAt: Date.now(), persisted: false };
}

export async function createAnnouncement(input: {
  title: string;
  message: string;
  severity: "info" | "warning" | "critical";
  audience?: string;
  classId?: number;
  createdByUserId?: number;
}) {
  const db = await getDb();
  if (db) {
    try {
      if (await hasRoster(db)) {
        const result = await db.insert(emergencyAnnouncements).values({ ...input, audience: input.audience ?? "All families" }).$returningId();
        return { id: result[0]?.id, success: true, persisted: true };
      }
    } catch (error) {
      console.warn("[Database] Announcement insert failed; keeping it in memory only:", error);
    }
  }
  const announcement = { id: Date.now(), title: input.title, message: input.message, severity: input.severity, audience: input.audience ?? "All families", publishedAt: Date.now() } as const;
  runtimeAnnouncements.unshift(announcement);
  return { id: announcement.id, success: true, persisted: false };
}

/** Records attendance. Marking the same student/date again updates the existing record instead of creating a duplicate. */
export async function recordAttendance(input: {
  studentId: number;
  status: "present" | "absent" | "late" | "excused";
  attendanceDate: string;
  classId?: number;
  recordedByUserId?: number;
}) {
  const db = await getDb();
  if (db) {
    try {
      const [existingStudent] = await db.select({ id: students.id }).from(students).where(eq(students.id, input.studentId)).limit(1);
      if (existingStudent) {
        const attendanceDate = new Date(`${input.attendanceDate}T00:00:00.000Z`);
        const updated = await db.transaction(async tx => {
          const [record] = await tx.select({ id: attendance.id }).from(attendance).where(and(eq(attendance.studentId, input.studentId), eq(attendance.attendanceDate, attendanceDate))).limit(1);
          if (record) {
            await tx.update(attendance).set({ status: input.status, classId: input.classId, recordedByUserId: input.recordedByUserId }).where(eq(attendance.id, record.id));
            return true;
          }
          await tx.insert(attendance).values({ studentId: input.studentId, classId: input.classId, attendanceDate, status: input.status, recordedByUserId: input.recordedByUserId });
          return false;
        });
        return { success: true, persisted: true, updated, recordedAt: Date.now() };
      }
      if (await hasRoster(db)) throw notFound(`Student ${input.studentId} was not found.`);
    } catch (error) {
      if (error instanceof AppError) throw error;
      console.warn("[Database] Attendance write failed; keeping it in memory only:", error);
    }
  }
  if (input.status === "excused") runtimeAttendanceOverrides.delete(input.studentId);
  else runtimeAttendanceOverrides.set(input.studentId, input.status);
  return { success: true, persisted: false, updated: false, recordedAt: Date.now() };
}

export async function seedDemoDataIfEmpty() {
  // Intentionally no-op in production. The UI and read APIs remain useful before the first school import via fallbackSnapshot().
  return false;
}

export { statusLabels, statusColors };
