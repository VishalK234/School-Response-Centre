import { TRPCError } from "@trpc/server";
import { COOKIE_NAME } from "@shared/const";
import {
  createAnnouncementSchema,
  createStudentSchema,
  idSchema,
  recordAttendanceSchema,
  studentListQuerySchema,
  updateStatusSchema,
} from "@shared/schemas";
import {
  createAnnouncement,
  createStudentRecord,
  getClassReport,
  getDashboardSnapshot,
  listAnnouncements,
  listClasses,
  listDashboardStudents,
  recordAttendance,
  updateStudentEmergencyStatus,
} from "./db";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { AppError, type AppErrorKind } from "./errors";
import { isStaff, redactSnapshot, redactStudents } from "./privacy";

const staffProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (!isStaff(ctx.user)) {
    throw new TRPCError({ code: "FORBIDDEN", message: "Staff access is required for this action." });
  }
  return next({ ctx });
});

type TrpcCode = ConstructorParameters<typeof TRPCError>[0]["code"];

const TRPC_CODE: Record<AppErrorKind, TrpcCode> = {
  not_found: "NOT_FOUND",
  conflict: "CONFLICT",
  unavailable: "SERVICE_UNAVAILABLE",
};

/** Turns data-layer errors into typed tRPC errors so clients get 404/409/503 instead of a generic 500. */
async function guarded<T>(work: () => Promise<T>): Promise<T> {
  try {
    return await work();
  } catch (error) {
    if (error instanceof AppError) throw new TRPCError({ code: TRPC_CODE[error.kind], message: error.message, cause: error });
    throw error;
  }
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    access: protectedProcedure.query(({ ctx }) => ({
      role: ctx.user.role,
      permissions: ctx.user.role === "admin"
        ? ["manage_roster", "manage_users", "publish_announcements", "update_emergency_status", "record_attendance", "export_reports"]
        : ctx.user.role === "teacher"
          ? ["view_assigned_classes", "record_attendance", "update_emergency_status", "view_reports"]
          : ["view_public_status"],
    })),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  dashboard: router({
    // Guardian phone numbers are masked unless the caller is signed-in staff.
    snapshot: publicProcedure.query(async ({ ctx }) => redactSnapshot(await getDashboardSnapshot(), isStaff(ctx.user))),
  }),
  students: router({
    list: publicProcedure.input(studentListQuerySchema.optional()).query(async ({ input, ctx }) => redactStudents(await listDashboardStudents(input), isStaff(ctx.user))),
    create: staffProcedure.input(createStudentSchema).mutation(({ input }) => guarded(() => createStudentRecord(input))),
    updateStatus: staffProcedure.input(updateStatusSchema).mutation(({ input, ctx }) => guarded(() => updateStudentEmergencyStatus({ ...input, reportedByUserId: ctx.user.id }))),
  }),
  classes: router({
    list: publicProcedure.query(() => listClasses()),
    report: publicProcedure.input(z.object({ classId: idSchema })).query(async ({ input, ctx }) => {
      const report = await getClassReport(input.classId);
      if (!report.class) throw new TRPCError({ code: "NOT_FOUND", message: "Class not found." });
      return { ...report, students: redactStudents(report.students, isStaff(ctx.user)) };
    }),
  }),
  attendance: router({
    record: staffProcedure.input(recordAttendanceSchema).mutation(({ input, ctx }) => guarded(() => recordAttendance({ ...input, recordedByUserId: ctx.user.id }))),
  }),
  announcements: router({
    list: publicProcedure.query(() => listAnnouncements()),
    create: staffProcedure.input(createAnnouncementSchema).mutation(({ input, ctx }) => guarded(() => createAnnouncement({ ...input, createdByUserId: ctx.user.id }))),
  }),
});

export type AppRouter = typeof appRouter;
