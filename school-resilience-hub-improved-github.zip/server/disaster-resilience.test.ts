import { beforeAll, describe, expect, it, vi } from "vitest";

// These tests exercise the built-in fallback path and must never touch a real database,
// even if DATABASE_URL is set in the developer's shell. vi.hoisted runs before any import.
vi.hoisted(() => {
  delete process.env.DATABASE_URL;
});

import { createAnnouncement, getClassReport, getDashboardSnapshot, recordAttendance, updateStudentEmergencyStatus } from "./db";
import { appRouter } from "./routers";
import { isStaff, maskPhone, redactSnapshot } from "./privacy";
import type { TrpcContext } from "./_core/context";

type ContextUser = NonNullable<TrpcContext["user"]>;

function makeContext(role: ContextUser["role"] | null): TrpcContext {
  const user: ContextUser | null = role
    ? { id: 1, openId: `test-${role}`, name: `Test ${role}`, email: null, loginMethod: "manus", role, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() }
    : null;
  return { user, req: {} as TrpcContext["req"], res: {} as TrpcContext["res"] };
}

const caller = (role: ContextUser["role"] | null) => appRouter.createCaller(makeContext(role));

beforeAll(() => {
  expect(process.env.DATABASE_URL).toBeUndefined();
});

describe("dashboard snapshot", () => {
  it("is clearly labelled as demonstration data when no database is connected", async () => {
    const snapshot = await getDashboardSnapshot();
    expect(snapshot.source).toBe("fallback");
    expect(snapshot.summary.totalStudents).toBeGreaterThan(0);
  });

  it("returns every emergency category in a stable order", async () => {
    const snapshot = await getDashboardSnapshot();
    expect(snapshot.statusBreakdown.map(item => item.label)).toEqual([
      "Safe",
      "Needs assistance",
      "Missing / unreachable",
      "Hospitalized",
      "Evacuated",
    ]);
  });

  it("keeps summary counts and the status breakdown consistent after a status change", async () => {
    // Student 101 starts as "safe" in the demo data.
    await updateStudentEmergencyStatus({ studentId: 101, status: "missing", location: "Main gate" });
    const { summary, statusBreakdown } = await getDashboardSnapshot();
    const byLabel = Object.fromEntries(statusBreakdown.map(item => [item.label, item.value]));
    expect(byLabel["Missing / unreachable"]).toBe(summary.missing);
    expect(byLabel["Safe"]).toBe(summary.safe);
    expect(statusBreakdown.reduce((sum, item) => sum + item.value, 0)).toBe(summary.totalStudents);
  });
});

describe("class reports", () => {
  it("returns the class roster with a full status breakdown", async () => {
    const report = await getClassReport(1);
    expect(report.class?.name).toBeTruthy();
    expect(report.students.length).toBeGreaterThan(0);
    expect(report.students.every(student => student.classId === 1)).toBe(true);
    expect(report.statusBreakdown).toHaveLength(5);
  });

  it("returns a null class for an id that does not exist", async () => {
    const report = await getClassReport(987654);
    expect(report.class).toBeNull();
    expect(report.students).toEqual([]);
  });

  it("surfaces an unknown class as NOT_FOUND through tRPC", async () => {
    await expect(caller(null).classes.report({ classId: 987654 })).rejects.toMatchObject({ code: "NOT_FOUND" });
  });
});

describe("access control", () => {
  it("rejects anonymous writes as UNAUTHORIZED", async () => {
    await expect(caller(null).students.updateStatus({ studentId: 101, status: "safe" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("rejects non-staff users as FORBIDDEN", async () => {
    await expect(caller("student").students.updateStatus({ studentId: 101, status: "safe" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller("user").announcements.create({ title: "Hello there", message: "Not allowed", severity: "info" })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("lets teachers and admins write", async () => {
    const teacher = await caller("teacher").students.updateStatus({ studentId: 102, status: "safe", location: "North shelter" });
    expect(teacher.success).toBe(true);
    const admin = await caller("admin").attendance.record({ studentId: 102, status: "present", attendanceDate: "2026-09-19" });
    expect(admin.success).toBe(true);
  });

  it("identifies staff roles", () => {
    expect(isStaff({ role: "admin" })).toBe(true);
    expect(isStaff({ role: "teacher" })).toBe(true);
    expect(isStaff({ role: "student" })).toBe(false);
    expect(isStaff(null)).toBe(false);
  });
});

describe("privacy", () => {
  it("masks guardian phone numbers, keeping only the last four digits", () => {
    const masked = maskPhone("+91 9810001042");
    expect(masked.endsWith("1042")).toBe(true);
    expect(masked).not.toContain("98100");
    expect(maskPhone("Not provided")).toBe("Not provided");
    expect(maskPhone("12")).not.toContain("12");
  });

  it("masks phones for public viewers and leaves them intact for staff", async () => {
    // The demo data is already masked, so plant a full number to prove redaction really happens.
    const base = await getDashboardSnapshot();
    const planted = { ...base, students: base.students.map(student => ({ ...student, guardianPhone: "+91 9810001042" })) };

    const publicView = redactSnapshot(planted, false);
    expect(publicView.students.length).toBeGreaterThan(0);
    for (const student of publicView.students) {
      expect(student.guardianPhone).not.toContain("98100");
      expect(student.guardianPhone.endsWith("1042")).toBe(true);
    }

    const staffView = redactSnapshot(planted, true);
    for (const student of staffView.students) expect(student.guardianPhone).toBe("+91 9810001042");
  });

  it("applies redaction on the public tRPC endpoints", async () => {
    const publicList = await caller(null).students.list();
    const staffList = await caller("teacher").students.list();
    expect(publicList).toHaveLength(staffList.length);
    for (const student of publicList) expect(student.guardianPhone).toBe(maskPhone(staffList.find(item => item.id === student.id)!.guardianPhone));
  });
});

describe("validation", () => {
  it("rejects malformed attendance dates instead of passing them to the database", async () => {
    await expect(caller("teacher").attendance.record({ studentId: 101, status: "present", attendanceDate: "not-a-date" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(caller("teacher").attendance.record({ studentId: 101, status: "present", attendanceDate: "2026-13-45" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("rejects out-of-range and unknown values", async () => {
    await expect(caller("teacher").students.updateStatus({ studentId: 0, status: "safe" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(caller("teacher").announcements.create({ title: "ab", message: "too short title", severity: "info" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });
});

describe("resilient write path (no database)", () => {
  it("publishes announcements and shows them on the dashboard", async () => {
    const title = `Test broadcast ${Date.now()}`;
    const announcement = await createAnnouncement({ title, message: "Please remain at the assigned shelter.", severity: "warning" });
    expect(announcement.success).toBe(true);
    expect(announcement.persisted).toBe(false);
    const snapshot = await getDashboardSnapshot();
    expect(snapshot.announcements.some(item => item.title === title)).toBe(true);
  });

  it("reports that fallback writes were not persisted", async () => {
    const status = await updateStudentEmergencyStatus({ studentId: 999999, status: "safe", location: "North shelter" });
    expect(status).toMatchObject({ success: true, persisted: false });
    const attendance = await recordAttendance({ studentId: 999998, status: "present", attendanceDate: "2026-09-19" });
    expect(attendance).toMatchObject({ success: true, persisted: false });
  });
});
