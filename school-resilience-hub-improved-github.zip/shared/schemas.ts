import { z } from "zod";

/**
 * Single source of truth for request validation. Both the tRPC routers and
 * the REST routes import from here so the two APIs cannot drift apart.
 */

export const EMERGENCY_STATUSES = ["safe", "needs_assistance", "missing", "hospitalized", "evacuated"] as const;
export const ATTENDANCE_STATUSES = ["present", "absent", "late", "excused"] as const;
export const ANNOUNCEMENT_SEVERITIES = ["info", "warning", "critical"] as const;

export const emergencyStatusSchema = z.enum(EMERGENCY_STATUSES);
export const attendanceStatusSchema = z.enum(ATTENDANCE_STATUSES);
export const severitySchema = z.enum(ANNOUNCEMENT_SEVERITIES);

export const idSchema = z.number().int().positive();

export const studentListQuerySchema = z.object({
  status: emergencyStatusSchema.optional(),
  search: z.string().max(100).optional(),
});

export const createStudentSchema = z.object({
  studentCode: z.string().min(2).max(40),
  firstName: z.string().min(1).max(80),
  lastName: z.string().min(1).max(80),
  gradeLevel: z.string().min(1).max(40),
  classId: idSchema.optional(),
  guardianName: z.string().max(160).optional(),
  guardianPhone: z.string().max(40).optional(),
});

export const updateStatusBodySchema = z.object({
  status: emergencyStatusSchema,
  location: z.string().max(160).optional(),
  notes: z.string().max(1000).optional(),
});

export const updateStatusSchema = updateStatusBodySchema.extend({ studentId: idSchema });

export const recordAttendanceSchema = z.object({
  studentId: idSchema,
  status: attendanceStatusSchema,
  // Strict YYYY-MM-DD. The old `min(8)` check let garbage through to the database.
  attendanceDate: z.iso.date(),
  classId: idSchema.optional(),
});

export const createAnnouncementSchema = z.object({
  title: z.string().min(3).max(180),
  message: z.string().min(5).max(5000),
  severity: severitySchema,
  audience: z.string().max(80).optional(),
  classId: idSchema.optional(),
});
