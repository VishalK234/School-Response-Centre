# Contributing

Thank you for contributing to Northstar School Resilience Hub. Changes should preserve the safety, auditability, and reproducibility of the emergency-management workflow.

## Development workflow

Create a focused branch from `main`. Install dependencies with `pnpm install`, copy `.env.example` to `.env`, and configure a development database before running `pnpm dev`.

Keep frontend changes in `client/`, backend procedures and database helpers in `server/`, schema and migrations in `drizzle/`, and reusable documentation in `docs/`. Do not edit generated framework files unless the change extends the runtime itself.

## Database changes

Update `drizzle/schema.ts`, generate a migration, review the generated SQL, and apply it to the target database. Include the migration in the same pull request as the schema change. Never commit credentials or production student data.

## Validation requirements

Before opening a pull request, run:

```bash
pnpm check
pnpm test
pnpm build
```

Add or update Vitest coverage for backend behavior and write-path changes. For UI changes, verify loading, empty, error, mobile, and authenticated states where applicable.

## Pull requests

Describe the user-facing problem, the implementation, the database impact, and the verification performed. Include screenshots only when they help reviewers understand a visual change. Do not include personally identifiable student information in screenshots or issue reports.

## Security reports

Do not report suspected security issues in a public issue. Contact the project maintainer privately with the smallest reproducible description and avoid sharing real credentials or student data.
